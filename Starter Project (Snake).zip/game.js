
const board = document.getElementById('board'), scEl = document.getElementById('score'), lvlEl = document.getElementById('cur-lvl');
const ovEl = document.getElementById('over'), fsEl = document.getElementById('fscore'), bgLayer = document.getElementById('bg-layer');
const celBox = document.getElementById('celebration-box'), celSticker = document.getElementById('cel-sticker'), celWord = document.getElementById('cel-word');
const canvas = document.getElementById('confetti-canvas'), ctx = canvas.getContext('2d'), ap = document.getElementById('ap');

let grid = Array.from({ length: 8 }, () => Array(8).fill(null));
let score = 0, best = Number(localStorage.getItem('bbBest')) || 0, maxLvl = Number(localStorage.getItem('bbLvl')) || 1;
let curLvl = 1, slots = [null, null, null], sfxOn = true, actx = null, tm = null, step = 0;
let bombs = 1, swaps = 2, bombMode = false, nextLvlScore = 1000, isTutorial = false;

function requestNotif() {
  if (!('Notification' in window)) return;
  Notification.requestPermission().then(res => {
    const btn = document.getElementById('notif-btn');
    if (res === 'granted') {
      if (btn) btn.innerText = 'Yoqiq 🔔';
      sendNotif('Block Blast Stiker', 'Bildirishnomalar yoqildi! Yangi rekordlar sari olgʻa 🏆');
    } else if (btn) btn.innerText = 'Rad etildi 🔕';
  });
}

function sendNotif(title, body) {
  if ('Notification' in window && Notification.permission === 'granted') {
    try { new Notification(title, { body }); } catch (e) {}
  }
}

const RANKS = 'Yangi,Havaskor,Usta,Mutaxassis,Chempion,Afsona'.split(',');
function updateMenuStats() {
  document.getElementById('menu-best').innerText = best;
  document.getElementById('menu-rank').innerText = RANKS.at(Math.min(maxLvl - 1, RANKS.length - 1));
}
updateMenuStats();

function resizeCanvas() { canvas.width = window.innerWidth; canvas.height = window.innerHeight; }
window.addEventListener('resize', resizeCanvas); resizeCanvas();

function stopAllAudio() { clearInterval(tm); ap.pause(); }
document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    stopAllAudio();
    if (score > 0) setTimeout(() => { if (document.hidden) sendNotif('Oʻyinga qayting! 🤩', 'Sizning balingiz: ' + score); }, 10000);
  }
});
window.addEventListener('pagehide', stopAllAudio); window.addEventListener('blur', stopAllAudio);

function initAudio() { if (!actx) { const A = window.AudioContext || window.webkitAudioContext; actx = new A(); } if (actx.state === 'suspended') actx.resume(); }
function tone(f, t, d, v = 0.14) {
  try {
    initAudio(); const n = actx.currentTime, o = actx.createOscillator(), g = actx.createGain();
    o.type = t; o.frequency.setValueAtTime(f, n); g.gain.setValueAtTime(v, n); g.gain.exponentialRampToValueAtTime(0.001, n + d);
    o.connect(g); g.connect(actx.destination); o.start(); o.stop(n + d);
  } catch (e) {}
}
function playWowSound() {
  if (!sfxOn) return;
  try {
    initAudio(); const n = actx.currentTime, o = actx.createOscillator(), g = actx.createGain();
    o.type = 'sawtooth'; o.frequency.setValueAtTime(220, n); o.frequency.exponentialRampToValueAtTime(580, n + 0.25);
    g.gain.setValueAtTime(0.18, n); g.gain.exponentialRampToValueAtTime(0.001, n + 0.6);
    o.connect(g); g.connect(actx.destination); o.start(); o.stop(n + 0.6);
    '523,659,784,1046'.split(',').map(Number).forEach((f, i) => setTimeout(() => tone(f, 'triangle', 0.25, 0.16), i * 80));
  } catch (e) {}
}
function playSfx(k) {
  if (!sfxOn) return;
  if (k === 'pick') tone(440, 'sine', 0.06);
  if (k === 'drop') { tone(280, 'triangle', 0.1); tone(350, 'triangle', 0.1); }
  if (k === 'bomb') { tone(120, 'sawtooth', 0.35, 0.25); tone(80, 'square', 0.4, 0.2); }
  if (k === 'err') tone(160, 'sawtooth', 0.1);
  if (k === 'over') '392,349,329,261'.split(',').map(Number).forEach((f, i) => setTimeout(() => tone(f, 'triangle', 0.25), i * 140));
}
function toggleSfx() { sfxOn = !sfxOn; document.getElementById('sfx-btn').innerText = sfxOn ? 'Yoqiq 🔊' : 'Oʻchiq 🔇'; }

const TRACKS = {
  tetris: '659,494,523,587,523,494,440,440,523,659,587,523,494,523,587,659,523,440,440,0'.split(',').map(Number),
  lofi: '261,329,392,493,392,329,293,349,440,523,440,349,0'.split(',').map(Number),
  arcade: '330,392,659,523,587,784,0,330,392,659,523,587,784,0'.split(',').map(Number)
};
function changeMusic() {
  stopAllAudio(); step = 0; const v = document.getElementById('bgm-select').value;
  if (v === 'none') return;
  if (v === 'custom') { ap.volume = 0.5; ap.play(); return; }
  initAudio(); const nt = TRACKS[v];
  tm = setInterval(() => { if (!document.hidden) { const f = nt.at(step % nt.length); step++; if (f > 0) tone(f, v === 'lofi' ? 'sine' : 'triangle', 0.2, 0.05); } }, v === 'lofi' ? 350 : 240);
}
function loadCustomAudio(e) {
  const f = e.target.files.item(0); if (!f) return; ap.src = URL.createObjectURL(f);
  const o = document.getElementById('custom-opt'); o.style.display = 'block'; o.innerText = f.name.slice(0, 14);
  document.getElementById('bgm-select').value = 'custom'; changeMusic();
}
const BGS = { space: 'radial-gradient(circle at top, #1e2749, #0b0e1a)', forest: 'linear-gradient(135deg, #0b3d2e, #1a5e44, #08241b)', sunset: 'linear-gradient(135deg, #4a154b, #9e2a2b, #e09f3e)', neon: 'linear-gradient(135deg, #10002b, #3c096c, #240046)' };
function changeBg() { const v = document.getElementById('bg-select').value; if (BGS[v]) bgLayer.style.backgroundImage = BGS[v]; }
function loadCustomBg(e) {
  const f = e.target.files.item(0); if (!f) return; bgLayer.style.backgroundImage = 'url(' + URL.createObjectURL(f) + ')';
  const o = document.getElementById('custom-bg-opt'); o.style.display = 'block'; o.innerText = f.name.slice(0, 14);
  document.getElementById('bg-select').value = 'custom';
}

let particles = [];
function launchConfetti() {
  particles = []; const colors = '#ff595e,#ffca3a,#8ac926,#1982c4,#f15bb5,#00f5d4'.split(',');
  for (let i = 0; i < 85; i++) particles.push({ x: canvas.width / 2, y: canvas.height * 0.45, vx: (Math.random() - 0.5) * 16, vy: (Math.random() - 0.7) * 16, size: Math.random() * 8 + 5, color: colors.at(Math.floor(Math.random() * colors.length)), rot: Math.random() * 360, life: 100 });
  animateConfetti();
}
function animateConfetti() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  particles.forEach(p => { p.x += p.vx; p.y += p.vy; p.vy += 0.35; p.rot += 6; p.life--; ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot * Math.PI / 180); ctx.fillStyle = p.color; ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6); ctx.restore(); });
  particles = particles.filter(p => p.life > 0);
  if (particles.length > 0) requestAnimationFrame(animateConfetti);
}

const MISSION_WORDS = 'GʻOLIB,OLTIN,ZAFAR,YULDUZ,SUPER'.split(',');
let targetWord = 'GʻOLIB', collectedMap = {};
function setupWordMission() { targetWord = MISSION_WORDS.at((curLvl - 1) % MISSION_WORDS.length); collectedMap = {}; renderWordMission(); }
function renderWordMission() {
  const box = document.getElementById('target-letters'); box.innerHTML = '';
  for (let i = 0; i < targetWord.length; i++) {
    const ch = targetWord.charAt(i), d = document.createElement('div');
    d.className = 't-let' + (collectedMap[i] ? ' done' : ''); d.innerText = ch; box.appendChild(d);
  }
}
function checkCollectedLetter(ch) {
  for (let i = 0; i < targetWord.length; i++) if (targetWord.charAt(i) === ch && !collectedMap[i]) { collectedMap[i] = true; renderWordMission(); break; }
  if (Object.keys(collectedMap).length === targetWord.length) { bombs++; updatePwrUI(); addScore(500); celebrate('🏆', targetWord + ' +500!'); setTimeout(setupWordMission, 1200); }
}

const makePack = (w, l, e, s, c) => ({ word: w, letters: l.split(','), emojis: e.split(','), sticker: s, color: c });
const PACKS = [
  makePack('ZOʻR!', 'Gʻ,O,L,I,B', '😔,🙂,😄,🤩,🔥', '👏', '#ff595e'),
  makePack('BRAVO!', 'O,L,T,I,N', '😐,😊,😁,🥳,😍', '🎉', '#ffca3a'),
  makePack('SUPER!', 'Z,A,F,A,R', '😕,😌,😀,😎,🔥', '🔥', '#8ac926'),
  makePack('AJOYIB!', 'Y,U,L,D,U,Z', '🥺,🙂,😄,🤗,✨,🌟', '🤩', '#1982c4'),
  makePack('BARAKALLA!', 'S,U,P,E,R', '😶,😊,😁,😃,👏', '🏆', '#f15bb5')
];
const SHAPES = '1|11|1,1|111|1,1,1|11,11|10,10,11|01,01,11|111,010|110,011'.split('|').map(s => s.split(',').map(r => r.split('').map(Number)));
function celebrate(stk, txt) { celSticker.innerText = stk; celWord.innerText = txt; celBox.classList.remove('show'); void celBox.offsetWidth; celBox.classList.add('show'); launchConfetti(); playWowSound(); }
 
function openModal(id) {
  if (id === 'levels-modal') {
    const g = document.getElementById('levels-grid'); g.innerHTML = '';
    for (let i = 1; i <= 12; i++) {
      const d = document.createElement('div'); d.className = 'lvl-item' + (i <= maxLvl ? ' unlocked' : ''); d.innerText = i <= maxLvl ? i : '🔒';
      if (i <= maxLvl) d.onclick = () => { curLvl = i; closeModals(); startNewGame(false); }; g.appendChild(d);
    }
  }
  document.getElementById(id).style.display = 'flex';
}
function closeModals() { document.querySelectorAll('.modal').forEach(m => m.style.display = 'none'); }
function goMenu() { stopAllAudio(); updateMenuStats(); document.getElementById('game-screen').style.display = 'none'; ovEl.style.display = 'none'; document.getElementById('menu-screen').style.display = 'flex'; }
function startPlay() {
  requestNotif();
  document.getElementById('menu-screen').style.display = 'none';
  document.getElementById('game-screen').style.display = 'flex';
  startNewGame(!localStorage.getItem('bbTutDone'));
}

function startNewGame(withTut) {
  grid = Array.from({ length: 8 }, () => Array(8).fill(null));
  score = 0; bombs = 1; swaps = 2; bombMode = false; nextLvlScore = curLvl * 1000;
  scEl.innerText = 0; lvlEl.innerText = curLvl; ovEl.style.display = 'none';
  setupWordMission(); updatePwrUI(); initBoard();
  if (withTut) setupTutorial();
  else {
    isTutorial = false; document.getElementById('tut-hand').style.display = 'none'; document.getElementById('tut-hint').style.display = 'none';
    if (curLvl >= 2) addFrozenBlocks(Math.min(curLvl, 5));
    spawn();
  }
}

function setupTutorial() {
  isTutorial = true;
  for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) if (!((r === 3 || r === 4) && (c === 3 || c === 4))) grid[r][c] = { color: '#3a86ff', emo: '😊', let: 'O', frozen: false };
  render();
  '3,3|3,4|4,3|4,4'.split('|').forEach(pair => { const [tr, tc] = pair.split(','); document.querySelector('.cell[data-r="' + tr + '"][data-c="' + tc + '"]').classList.add('tut-target'); });
  document.getElementById('tut-hint').style.display = 'block';
  const hand = document.getElementById('tut-hand'), rc = board.getBoundingClientRect();
  hand.style.display = 'block'; hand.style.left = (rc.left + rc.width / 2 - 15) + 'px'; hand.style.top = (rc.top + rc.height / 2) + 'px';
  for (let i = 0; i < 3; i++) document.getElementById('s' + i).innerHTML = '';
  const m = '11,11'.split(',').map(r => r.split('').map(Number)), pk = PACKS.at(0);
  const cd = [[{ color: '#ffd166', emo: '🤩', let: 'Z' }, { color: '#ffd166', emo: '🤩', let: 'Oʻ' }], [{ color: '#ffd166', emo: '🤩', let: 'R' }, { color: '#ffd166', emo: '🤩', let: '!' }]];
  const sh = { m, cellsData: cd, pack: pk }; slots = [null, sh, null];
  const p = document.createElement('div'); p.className = 'piece'; p.style.gridTemplateColumns = 'repeat(2, 22px)';
  cd.forEach(rw => rw.forEach(it => { const pc = document.createElement('div'); pc.className = 'p-cell'; pc.style.background = it.color; pc.innerHTML = '<span class="c-emo">' + it.emo + '</span><span class="c-let">' + it.let + '</span>'; p.appendChild(pc); }));
  setupDrag(p, sh, document.getElementById('s1'), 1); document.getElementById('s1').appendChild(p);
}

function addFrozenBlocks(cnt) { for (let i = 0; i < cnt; i++) { const r = Math.floor(Math.random() * 5) + 2, c = Math.floor(Math.random() * 8); grid[r][c] = { color: '#48cae4', emo: '❄️', let: 'M', frozen: true }; } render(); }
function initBoard() {
  board.innerHTML = '';
  for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) { const d = document.createElement('div'); d.className = 'cell'; d.dataset.r = r; d.dataset.c = c; d.addEventListener('click', () => { if (bombMode) detonateBomb(r, c); }); board.appendChild(d); }
}
function render() {
  document.querySelectorAll('.cell').forEach(d => {
    const r = Number(d.dataset.r), c = Number(d.dataset.c); d.classList.remove('preview', 'frozen'); d.innerHTML = '';
    if (grid[r][c]) { const cd = grid[r][c]; d.style.background = cd.color; d.classList.add('filled'); if (cd.frozen) d.classList.add('frozen'); d.innerHTML = '<span class="c-emo">' + (cd.frozen ? '❄️' : cd.emo) + '</span><span class="c-let">' + cd.let + '</span>'; }
    else { d.style.background = 'rgba(24, 28, 51, 0.9)'; d.classList.remove('filled'); }
  });
}
function updatePwrUI() { document.getElementById('bomb-cnt').innerText = bombs; document.getElementById('swap-cnt').innerText = swaps; document.getElementById('bomb-btn').classList.toggle('active', bombMode); board.classList.toggle('bomb-mode', bombMode); }
function activateBomb() { if (bombs > 0) { bombMode = !bombMode; updatePwrUI(); } else playSfx('err'); }
function detonateBomb(cr, cc) {
  bombMode = false; bombs--; updatePwrUI(); playSfx('bomb');
  for (let r = cr - 1; r <= cr + 1; r++) for (let c = cc - 1; c <= cc + 1; c++) if (r >= 0 && r < 8 && c >= 0 && c < 8) { grid[r][c] = null; const d = document.querySelector('.cell[data-r="' + r + '"][data-c="' + c + '"]'); if (d) d.classList.add('flash'); }
  launchConfetti(); applyGravity(); render(); checkOver();
}
function useSwap() { if (swaps > 0 && !isTutorial) { swaps--; updatePwrUI(); playSfx('pick'); spawn(); } else playSfx('err'); }
function spawn() {
  for (let i = 0; i < 3; i++) {
    const sl = document.getElementById('s' + i); sl.innerHTML = '';
    const m = SHAPES.at(Math.floor(Math.random() * SHAPES.length)), pack = PACKS.at(Math.floor(Math.random() * PACKS.length)); let idx = 0;
    const cellsData = m.map(row => row.map(v => { if (!v) return null; const gft = Math.random() < 0.08; const it = { color: pack.color, emo: gft ? '🎁' : pack.emojis.at(idx % pack.emojis.length), let: pack.letters.at(idx % pack.letters.length), gift: gft, frozen: false }; idx++; return it; }));
    const sh = { m, cellsData, pack }; slots[i] = sh;
    const cols = m.reduce((a, r) => Math.max(a, r.length), 0), p = document.createElement('div'); p.className = 'piece'; p.style.gridTemplateColumns = 'repeat(' + cols + ', 22px)';
    cellsData.forEach(rw => rw.forEach(it => { const pc = document.createElement('div'); pc.className = 'p-cell'; if (it) { pc.style.background = it.color; pc.innerHTML = '<span class="c-emo">' + it.emo + '</span><span class="c-let">' + it.let + '</span>'; } p.appendChild(pc); }));
    setupDrag(p, sh, sl, i); sl.appendChild(p);
  }
  checkOver();
}

let cl = null, csh = null, csl = null, cidx = -1, lastTarget = null;
function setupDrag(el, sh, sl, idx) {
  el.addEventListener('touchstart', e => {
    if (bombMode) return; e.preventDefault(); playSfx('pick'); csh = sh; csl = sl; cidx = idx;
    cl = el.cloneNode(true); cl.classList.add('dragging'); document.body.appendChild(cl);
    el.style.opacity = '0.2'; moveClone(e.touches.item(0));
  });
  el.addEventListener('touchmove', e => { if (!cl) return; const t = e.touches.item(0); moveClone(t); highlight(t); });
  el.addEventListener('touchend', e => {
    if (!cl) return;
    if (lastTarget && canPlace(csh.m, lastTarget.r, lastTarget.c)) {
      place(csh, lastTarget.r, lastTarget.c); playSfx('drop'); csl.innerHTML = ''; slots[cidx] = null;
      if (isTutorial) {
        isTutorial = false; localStorage.setItem('bbTutDone', '1');
        document.getElementById('tut-hand').style.display = 'none'; document.getElementById('tut-hint').style.display = 'none';
        document.querySelectorAll('.tut-target').forEach(x => x.classList.remove('tut-target'));
        grid = Array.from({ length: 8 }, () => Array(8).fill(null)); celebrate('🎉', 'AJOYIB! BOSHLADIK!'); addScore(200); render(); spawn();
      } else { resolveBoard(csh.pack, 1); if (slots.every(s => !s)) spawn(); else checkOver(); }} else { el.style.opacity = '1'; playSfx('err'); }
    cl.remove(); cl = null; lastTarget = null; render();
  });
}
function moveClone(t) { cl.style.left = t.clientX + 'px'; cl.style.top = t.clientY + 'px'; }
function calcTarget(t) {
  const rc = board.getBoundingClientRect(), sz = rc.width / 8;
  const cols = csh.m.reduce((a, r) => Math.max(a, r.length), 0), rows = csh.m.length;
  const visualCenterY = t.clientY - (rows * 22 * 1.85 * 0.95);
  const c = Math.round((t.clientX - rc.left) / sz - cols / 2), r = Math.round((visualCenterY - rc.top) / sz - rows / 2);
  return (r >= 0 && r <= 8 - rows && c >= 0 && c <= 8 - cols) ? { r, c } : null;
}
function highlight(t) {
  render(); lastTarget = calcTarget(t); if (!lastTarget || !canPlace(csh.m, lastTarget.r, lastTarget.c)) { lastTarget = null; return; }
  for (let r = 0; r < csh.m.length; r++) for (let c = 0; c < csh.m[r].length; c++) if (csh.m[r][c]) { const d = document.querySelector('.cell[data-r="' + (lastTarget.r + r) + '"][data-c="' + (lastTarget.c + c) + '"]'); if (d) { d.style.background = csh.pack.color; d.classList.add('preview'); } }
}
function canPlace(m, sr, sc) { for (let r = 0; r < m.length; r++) for (let c = 0; c < m[r].length; c++) if (m[r][c]) { const nr = sr + r, nc = sc + c; if (nr < 0 || nr >= 8 || nc < 0 || nc >= 8 || grid[nr][nc]) return false; } return true; }
function place(sh, sr, sc) { let k = 0; for (let r = 0; r < sh.m.length; r++) for (let c = 0; c < sh.m[r].length; c++) if (sh.m[r][c]) { grid[sr + r][sc + c] = Object.assign({}, sh.cellsData[r][c]); k++; } addScore(k * 10); }
function applyGravity() { for (let c = 0; c < 8; c++) { let col = []; for (let r = 0; r < 8; r++) if (grid[r][c]) col.push(grid[r][c]); for (let r = 7; r >= 0; r--) grid[r][c] = col.length > 0 ? col.pop() : null; } }
function resolveBoard(pack, chain) {
  let rs = [], cs = []; for (let r = 0; r < 8; r++) if (grid[r].every(v => v)) rs.push(r); for (let c = 0; c < 8; c++) if (grid.every(rw => rw[c])) cs.push(c);
  if (rs.length + cs.length > 0) {
    let clr = {}; rs.forEach(r => { for (let c = 0; c < 8; c++) clr[r + ',' + c] = true; }); cs.forEach(c => { for (let r = 0; r < 8; r++) clr[r + ',' + c] = true; });
    Object.keys(clr).forEach(k => {
const [r, c] = k.split(',').map(Number), cell = grid[r][c]; if (!cell) return;
if (cell.frozen) cell.frozen = false;
else { if (cell.gift) { swaps++; updatePwrUI(); } checkCollectedLetter(cell.let); grid[r][c] = null; const d = document.querySelector('.cell[data-r="' + r + '"][data-c="' + c + '"]'); if (d) d.classList.add('flash'); }
});
const b = (rs.length + cs.length) * 100 * chain; addScore(b);
celebrate(pack.sticker, chain > 1 ? 'ZANJIR x' + chain + ' +' + b : pack.word + ' +' + b);
setTimeout(() => { applyGravity(); render(); resolveBoard(pack, chain + 1); }, 380);
}
}
function addScore(p) {
score += p; scEl.innerText = score; if (score > best) { best = score; bsEl.innerText = best; localStorage.setItem('bbBest', best); sendNotif('Yangi Rekord! 🏆', 'Tabriklaymiz! Yangi rekord: ' + best); }
if (score >= nextLvlScore) { curLvl++; nextLvlScore += 1000; lvlEl.innerText = curLvl; if (curLvl > maxLvl) { maxLvl = curLvl; localStorage.setItem('bbLvl', maxLvl); } bombs++; updatePwrUI(); celebrate('👑', curLvl + '-DARAJA!'); sendNotif('Daraja oshdi! 👑', 'Siz ' + curLvl + '-darajaga oʻtdingiz!'); }
}
function canAnyFit() { for (let i = 0; i < 3; i++) { const s = slots[i]; if (!s) continue; for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) if (canPlace(s.m, r, c)) return true; } return false; }
function checkOver() { if (isTutorial || canAnyFit() || bombs > 0 || swaps > 0) return; setTimeout(() => { if (!canAnyFit() && bombs === 0 && swaps === 0) { playSfx('over'); fsEl.innerText = score; ovEl.style.display = 'flex'; } }, 500); }
function restart() { startNewGame(false); }